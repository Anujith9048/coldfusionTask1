$(document).ready(function () {
    $("#deleteList").click(function () {
        alert("hello");
        return;
    });
});